"use client"

import * as React from "react"
import {
  PlusIcon,
  PencilIcon,
  Trash2Icon,
  CheckIcon,
  XIcon,
} from "lucide-react"
import { getProducts, replaceProducts, type Product } from "@/lib/product-store"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"

const inputCls =
  "w-full rounded-md border bg-background px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-ring"

interface EditRowProps {
  draft: Product
  onDraftChange: (product: Product) => void
  onConfirm: () => void
  onCancel: () => void
}

function EditRow({ draft, onDraftChange, onConfirm, onCancel }: EditRowProps) {
  return (
    <TableRow className="bg-accent/20">
      <TableCell className="py-1.5 text-center">
        <input
          className={inputCls}
          value={draft.productCode}
          onChange={(e) => onDraftChange({ ...draft, productCode: e.target.value.toUpperCase() })}
          placeholder="LOC-001"
        />
      </TableCell>
      <TableCell className="py-1.5">
        <input
          className={inputCls}
          value={draft.productName}
          onChange={(e) => onDraftChange({ ...draft, productName: e.target.value })}
          placeholder="Location name"
        />
      </TableCell>
      <TableCell className="py-1.5">
        <input
          className={inputCls}
          value={draft.image}
          onChange={(e) => onDraftChange({ ...draft, image: e.target.value })}
          placeholder="Delivery"
        />
      </TableCell>
      <TableCell className="py-1.5">
        <div className="flex justify-center gap-1">
          <button
            onClick={onConfirm}
            className="rounded p-1 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 text-muted-foreground hover:text-emerald-600"
          >
            <CheckIcon className="size-3.5" />
          </button>
          <button
            onClick={onCancel}
            className="rounded p-1 hover:bg-muted text-muted-foreground"
          >
            <XIcon className="size-3.5" />
          </button>
        </div>
      </TableCell>
    </TableRow>
  )
}

interface EditProductsContentProps {
  onSaveRef?: React.MutableRefObject<(() => Promise<void>) | null>
}

export function EditProductsContent({ onSaveRef }: EditProductsContentProps) {
  const [products, setProducts] = React.useState<Product[]>([])
  const [drafts, setDrafts] = React.useState<Record<string, Product>>({})
  const [loading, setLoading] = React.useState(true)
  const [editingCode, setEditingCode] = React.useState<string | null>(null)
  const [adding, setAdding] = React.useState(false)
  const [confirmedDraftKey, setConfirmedDraftKey] = React.useState<string | null>(null)

  React.useEffect(() => {
    getProducts().then((items) => {
      setProducts(items)
      setLoading(false)
    })
  }, [])

  const handleSaveAll = React.useCallback(async () => {
    if (!confirmedDraftKey || !drafts[confirmedDraftKey]) return

    const nextByCode = new Map<string, Product>()

    for (const product of products) {
      const edited = drafts[product.productCode] ?? product
      const code = edited.productCode.trim().toUpperCase()
      const name = edited.productName.trim()
      if (!code || !name) continue

      if (!nextByCode.has(code)) {
        nextByCode.set(code, {
          productCode: code,
          productName: name,
          image: edited.image.trim(),
        })
      }
    }

    if (confirmedDraftKey === "new" && drafts.new) {
      const code = drafts.new.productCode.trim().toUpperCase()
      const name = drafts.new.productName.trim()
      if (code && name && !nextByCode.has(code)) {
        nextByCode.set(code, {
          productCode: code,
          productName: name,
          image: drafts.new.image.trim(),
        })
      }
    }

    const nextProducts = Array.from(nextByCode.values()).sort((a, b) =>
      a.productCode.localeCompare(b.productCode)
    )

    const ok = await replaceProducts(nextProducts)
    if (ok) {
      setProducts(nextProducts)
    }

    setDrafts({})
    setAdding(false)
    setEditingCode(null)
    setConfirmedDraftKey(null)
  }, [confirmedDraftKey, drafts, products])

  React.useEffect(() => {
    if (onSaveRef) {
      onSaveRef.current = handleSaveAll
    }
  }, [handleSaveAll, onSaveRef])

  async function handleDelete(productCode: string) {
    const response = await fetch(
      `/api/products?product_code=${encodeURIComponent(productCode)}`,
      { method: "DELETE" }
    )
    if (!response.ok) return
    setProducts((prev) => prev.filter((p) => p.productCode !== productCode))
  }

  function startAdd() {
    setAdding(true)
    setEditingCode(null)
    setConfirmedDraftKey(null)
    setDrafts({ new: { productCode: "", productName: "", image: "" } })
  }

  function startEdit(code: string) {
    const product = products.find((p) => p.productCode === code)
    if (product) {
      setEditingCode(code)
      setConfirmedDraftKey(null)
      setDrafts({ [code]: { ...product } })
    }
  }

  function confirmDraft() {
    if (adding && drafts.new) {
      setConfirmedDraftKey("new")
      setAdding(false)
      return
    }

    if (editingCode && drafts[editingCode]) {
      setConfirmedDraftKey(editingCode)
      setEditingCode(null)
    }
  }

  function cancelEdit() {
    if (adding) {
      setDrafts((prev) => {
        const next = { ...prev }
        delete next.new
        return next
      })
      if (confirmedDraftKey === "new") {
        setConfirmedDraftKey(null)
      }
    }

    if (editingCode) {
      setDrafts((prev) => {
        const next = { ...prev }
        delete next[editingCode]
        return next
      })
      if (confirmedDraftKey === editingCode) {
        setConfirmedDraftKey(null)
      }
    }

    setEditingCode(null)
    setAdding(false)
  }

  function updateDraft(code: string, product: Product) {
    setDrafts((prev) => ({ ...prev, [code]: product }))
  }

  if (loading) {
    return (
      <div className="py-10 text-center text-sm text-muted-foreground">
        Loading…
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          {products.length} location{products.length !== 1 && "s"} in master list
        </p>
        <Button
          size="sm"
          className="gap-1.5"
          onClick={startAdd}
          disabled={editingCode !== null || adding}
        >
          <PlusIcon className="size-3.5" />
          Add Location
        </Button>
      </div>

      <div className="rounded-xl border bg-card overflow-hidden text-xs">
        <Table className="text-xs">
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              {["Code", "Name", "Delivery", "Actions"].map((h) => (
                <TableHead
                  key={h}
                  className="text-center text-[11px] font-semibold tracking-wide py-2"
                >
                  {h}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {adding && drafts.new && (
              <EditRow
                draft={drafts.new}
                onDraftChange={(p) => updateDraft("new", p)}
                onConfirm={confirmDraft}
                onCancel={cancelEdit}
              />
            )}
            {drafts.new && !adding && confirmedDraftKey === "new" && (
              <TableRow className="h-10 bg-emerald-50/60 dark:bg-emerald-950/20">
                <TableCell className="text-center py-1.5 text-muted-foreground font-mono">
                  {drafts.new.productCode}
                </TableCell>
                <TableCell className="py-1.5 text-center">
                  <span className="font-medium truncate max-w-[200px]">
                    {drafts.new.productName}
                  </span>
                </TableCell>
                <TableCell className="py-1.5 text-center text-muted-foreground">
                  {drafts.new.image || "-"}
                  <span className="ml-2 text-[10px] text-emerald-600 font-medium uppercase tracking-wide">
                    Pending Save
                  </span>
                </TableCell>
                <TableCell className="py-1.5">
                  <div className="flex justify-center gap-1">
                    <button
                      onClick={() => {
                        setAdding(true)
                        setConfirmedDraftKey(null)
                      }}
                      className="rounded p-1 hover:bg-muted text-muted-foreground hover:text-foreground"
                    >
                      <PencilIcon className="size-3.5" />
                    </button>
                    <button
                      onClick={cancelEdit}
                      className="rounded p-1 hover:bg-red-100 dark:hover:bg-red-900/40 text-muted-foreground hover:text-red-500"
                    >
                      <Trash2Icon className="size-3.5" />
                    </button>
                  </div>
                </TableCell>
              </TableRow>
            )}
            {products.map((item) => {
              if (editingCode === item.productCode && drafts[item.productCode]) {
                return (
                  <EditRow
                    key={item.productCode}
                    draft={drafts[item.productCode]}
                    onDraftChange={(p) => updateDraft(item.productCode, p)}
                    onConfirm={confirmDraft}
                    onCancel={cancelEdit}
                  />
                )
              }

              const pendingDraft = confirmedDraftKey === item.productCode
                ? drafts[item.productCode]
                : undefined
              const displayItem = pendingDraft ?? item
              return (
                <TableRow key={item.productCode} className="h-10">
                  <TableCell className="text-center py-1.5 text-muted-foreground font-mono">
                    {displayItem.productCode}
                  </TableCell>
                  <TableCell className="py-1.5 text-center">
                    <span className="font-medium truncate max-w-[200px]">
                      {displayItem.productName}
                    </span>
                  </TableCell>
                  <TableCell className="py-1.5 text-center text-muted-foreground">
                    {displayItem.image || "-"}
                    {pendingDraft && (
                      <span className="ml-2 text-[10px] text-emerald-600 font-medium uppercase tracking-wide">
                        Pending Save
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="py-1.5">
                    <div className="flex justify-center gap-1">
                      <button
                        onClick={() => startEdit(item.productCode)}
                        className="rounded p-1 hover:bg-muted text-muted-foreground hover:text-foreground"
                      >
                        <PencilIcon className="size-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(item.productCode)}
                        className="rounded p-1 hover:bg-red-100 dark:hover:bg-red-900/40 text-muted-foreground hover:text-red-500"
                      >
                        <Trash2Icon className="size-3.5" />
                      </button>
                    </div>
                  </TableCell>
                </TableRow>
              )
            })}
            {products.length === 0 && !adding && (
              <TableRow>
                <TableCell
                  colSpan={4}
                  className="py-10 text-center text-muted-foreground"
                >
                  No locations yet.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
