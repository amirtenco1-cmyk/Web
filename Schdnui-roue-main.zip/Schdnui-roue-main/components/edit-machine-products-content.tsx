"use client"

import * as React from "react"
import {
  PlusIcon,
  PencilIcon,
  Trash2Icon,
  CheckIcon,
  XIcon,
} from "lucide-react"
import { getMachines, type Machine } from "@/lib/machine-store"
import { getProducts, type Product } from "@/lib/product-store"
import {
  getRouteLocations,
  upsertRouteLocations,
  deleteRouteLocation,
  type RouteLocation,
} from "@/lib/route-location-store"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"

interface AssignmentDraft {
  routeId: string
  locationCode: string
  originalLocationCode?: string
}

const inputCls =
  "w-full rounded-md border bg-background px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-ring"

interface AssignmentEditRowProps {
  products: Product[]
  draft: AssignmentDraft
  onDraftChange: (draft: AssignmentDraft) => void
  onConfirm: () => void
  onCancel: () => void
}

function AssignmentEditRow({
  products,
  draft,
  onDraftChange,
  onConfirm,
  onCancel,
}: AssignmentEditRowProps) {
  return (
    <TableRow className="bg-accent/20">
      <TableCell className="py-1.5 text-center font-mono text-muted-foreground">
        {draft.locationCode || "-"}
      </TableCell>
      <TableCell className="py-1.5">
        <select
          className={inputCls}
          value={draft.locationCode}
          onChange={(e) => onDraftChange({ ...draft, locationCode: e.target.value })}
        >
          <option value="">Select location</option>
          {products.map((p) => (
            <option key={p.productCode} value={p.productCode}>
              {p.productCode} — {p.productName}
            </option>
          ))}
        </select>
      </TableCell>
      <TableCell className="py-1.5 text-center text-muted-foreground">-</TableCell>
      <TableCell className="py-1.5">
        <div className="flex justify-center gap-1">
          <button
            onClick={onConfirm}
            className="rounded p-1 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 text-muted-foreground hover:text-emerald-600"
          >
            <CheckIcon className="size-3.5" />
          </button>
          <button
            onClick={onCancel}
            className="rounded p-1 hover:bg-muted text-muted-foreground"
          >
            <XIcon className="size-3.5" />
          </button>
        </div>
      </TableCell>
    </TableRow>
  )
}

interface EditMachineProductsContentProps {
  onSaveRef?: React.MutableRefObject<(() => Promise<void>) | null>
}

export function EditMachineProductsContent({ onSaveRef }: EditMachineProductsContentProps) {
  const [routes, setRoutes] = React.useState<Machine[]>([])
  const [products, setProducts] = React.useState<Product[]>([])
  const [assignments, setAssignments] = React.useState<RouteLocation[]>([])
  const [drafts, setDrafts] = React.useState<Record<string, AssignmentDraft>>({})
  const [loading, setLoading] = React.useState(true)
  const [selectedRouteId, setSelectedRouteId] = React.useState("")
  const [editingKey, setEditingKey] = React.useState<string | null>(null)
  const [adding, setAdding] = React.useState(false)
  const [confirmedDraftKey, setConfirmedDraftKey] = React.useState<string | null>(null)
  const [newAssignment, setNewAssignment] = React.useState<AssignmentDraft>({
    routeId: "",
    locationCode: "",
  })

  React.useEffect(() => {
    Promise.all([getMachines(), getProducts(), getRouteLocations()]).then(
      ([ms, ps, rs]) => {
        setRoutes(ms)
        setProducts(ps)
        setAssignments(rs)

        const first = ms[0]?.value ?? ""
        setSelectedRouteId(first)
        setNewAssignment((prev) => ({ ...prev, routeId: first }))
        setLoading(false)
      }
    )
  }, [])

  const assignmentKey = (item: Pick<RouteLocation, "routeId" | "locationCode">) =>
    `${item.routeId}::${item.locationCode}`

  const visibleAssignments = assignments
    .filter((item) => item.routeId === selectedRouteId)
    .sort((a, b) => a.locationCode.localeCompare(b.locationCode))

  const productMap = React.useMemo(
    () => new Map(products.map((p) => [p.productCode, p])),
    [products]
  )

  const handleSaveAll = React.useCallback(async () => {
    if (!confirmedDraftKey || !drafts[confirmedDraftKey]) return

    const upsertPayload: RouteLocation[] = []
    const seenKeys = new Set<string>()

    for (const [key, draft] of Object.entries(drafts)) {
      if (key !== confirmedDraftKey) continue

      const routeId = draft.routeId.trim()
      const locationCode = draft.locationCode.trim().toUpperCase()

      if (!routeId || !locationCode) continue

      if (draft.originalLocationCode && draft.originalLocationCode !== locationCode) {
        await deleteRouteLocation(routeId, draft.originalLocationCode)
      }

      const compositeKey = `${routeId}::${locationCode}`
      if (seenKeys.has(compositeKey)) continue
      seenKeys.add(compositeKey)

      upsertPayload.push({
        routeId,
        locationCode,
      })
    }

    if (upsertPayload.length > 0) {
      await upsertRouteLocations(upsertPayload)
    }

    const refreshed = await getRouteLocations()
    setAssignments(refreshed)

    setDrafts({})
    setAdding(false)
    setEditingKey(null)
    setConfirmedDraftKey(null)
  }, [confirmedDraftKey, drafts])

  React.useEffect(() => {
    if (onSaveRef) {
      onSaveRef.current = handleSaveAll
    }
  }, [handleSaveAll, onSaveRef])

  async function handleDelete(assignment: RouteLocation) {
    const ok = await deleteRouteLocation(assignment.routeId, assignment.locationCode)
    if (!ok) return

    setAssignments((prev) =>
      prev.filter((item) => assignmentKey(item) !== assignmentKey(assignment))
    )
  }

  function startAdd() {
    setAdding(true)
    setEditingKey(null)
    setConfirmedDraftKey(null)
    setDrafts({ new: { ...newAssignment, routeId: selectedRouteId } })
  }

  function startEdit(key: string) {
    const assignment = assignments.find((item) => assignmentKey(item) === key)
    if (assignment) {
      setEditingKey(key)
      setConfirmedDraftKey(null)
      setDrafts({
        [key]: {
          routeId: assignment.routeId,
          locationCode: assignment.locationCode,
          originalLocationCode: assignment.locationCode,
        },
      })
    }
  }

  function confirmDraft() {
    if (adding && drafts.new) {
      setConfirmedDraftKey("new")
      setAdding(false)
      return
    }

    if (editingKey && drafts[editingKey]) {
      setConfirmedDraftKey(editingKey)
      setEditingKey(null)
    }
  }

  function cancelEdit() {
    if (adding) {
      setDrafts((prev) => {
        const next = { ...prev }
        delete next.new
        return next
      })
      if (confirmedDraftKey === "new") {
        setConfirmedDraftKey(null)
      }
    }

    if (editingKey) {
      setDrafts((prev) => {
        const next = { ...prev }
        delete next[editingKey]
        return next
      })
      if (confirmedDraftKey === editingKey) {
        setConfirmedDraftKey(null)
      }
    }

    setEditingKey(null)
    setAdding(false)
  }

  function updateDraft(key: string, draft: AssignmentDraft) {
    setDrafts((prev) => ({ ...prev, [key]: draft }))
  }

  if (loading) {
    return (
      <div className="py-10 text-center text-sm text-muted-foreground">
        Loading…
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="rounded-xl border bg-card overflow-hidden text-xs">
        <div className="px-4 py-3 border-b flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between bg-muted/40">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold tracking-widest uppercase text-muted-foreground">
              Route
            </span>
            <select
              value={selectedRouteId}
              onChange={(e) => {
                setSelectedRouteId(e.target.value)
                setAdding(false)
                setEditingKey(null)
                setNewAssignment((prev) => ({
                  ...prev,
                  routeId: e.target.value,
                }))
              }}
              className="h-8 rounded-lg border bg-background px-2.5 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-ring text-foreground"
            >
              {routes.map((route) => (
                <option key={route.value} value={route.value}>
                  {route.value} — {route.label}
                </option>
              ))}
            </select>
          </div>
          <Button
            size="sm"
            className="gap-1.5"
            disabled={!selectedRouteId || products.length === 0 || editingKey !== null || adding}
            onClick={startAdd}
          >
            <PlusIcon className="size-3.5" />
            Add Location
          </Button>
        </div>

        <div className="overflow-x-auto">
          <Table className="text-xs min-w-[600px]">
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                {["Location Code", "Location", "Delivery", "Actions"].map((h) => (
                  <TableHead
                    key={h}
                    className="text-center text-[11px] font-semibold tracking-wide py-2"
                  >
                    {h}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {adding && drafts.new && (
                <AssignmentEditRow
                  products={products}
                  draft={drafts.new}
                  onDraftChange={(draft) => updateDraft("new", draft)}
                  onConfirm={confirmDraft}
                  onCancel={cancelEdit}
                />
              )}
              {drafts.new && !adding && confirmedDraftKey === "new" && (
                <TableRow className="h-10 bg-emerald-50/60 dark:bg-emerald-950/20">
                  <TableCell className="text-center py-1.5">
                    <span className="font-mono font-bold tracking-wider">
                      {drafts.new.locationCode}
                    </span>
                  </TableCell>
                  <TableCell className="py-1.5 text-center">
                    <span className="font-medium">
                      {productMap.get(drafts.new.locationCode)?.productName ?? "Unknown"}
                    </span>
                  </TableCell>
                  <TableCell className="text-center py-1.5 text-muted-foreground">
                    {productMap.get(drafts.new.locationCode)?.image || "-"}
                    <span className="ml-2 text-[10px] text-emerald-600 font-medium uppercase tracking-wide">
                      Pending Save
                    </span>
                  </TableCell>
                  <TableCell className="py-1.5">
                    <div className="flex justify-center gap-1">
                      <button
                        onClick={() => {
                          setAdding(true)
                          setConfirmedDraftKey(null)
                        }}
                        className="rounded p-1 hover:bg-muted text-muted-foreground hover:text-foreground"
                      >
                        <PencilIcon className="size-3.5" />
                      </button>
                      <button
                        onClick={cancelEdit}
                        className="rounded p-1 hover:bg-red-100 dark:hover:bg-red-900/40 text-muted-foreground hover:text-red-500"
                      >
                        <Trash2Icon className="size-3.5" />
                      </button>
                    </div>
                  </TableCell>
                </TableRow>
              )}
              {visibleAssignments.map((assignment) => {
                const key = assignmentKey(assignment)
                const location = productMap.get(assignment.locationCode)

                if (editingKey === key && drafts[key]) {
                  return (
                    <AssignmentEditRow
                      key={key}
                      products={products}
                      draft={drafts[key]}
                      onDraftChange={(draft) => updateDraft(key, draft)}
                      onConfirm={confirmDraft}
                      onCancel={cancelEdit}
                    />
                  )
                }

                const pendingDraft = confirmedDraftKey === key ? drafts[key] : undefined
                const displayLocationCode = pendingDraft?.locationCode ?? assignment.locationCode
                const displayLocation = productMap.get(displayLocationCode)

                return (
                  <TableRow key={key} className="h-10">
                    <TableCell className="text-center py-1.5">
                      <span className="font-mono font-bold tracking-wider">
                        {displayLocationCode}
                      </span>
                    </TableCell>
                    <TableCell className="py-1.5 text-center">
                      <span className="font-medium">
                        {displayLocation?.productName ?? assignment.locationName ?? "Unknown"}
                      </span>
                    </TableCell>
                    <TableCell className="text-center py-1.5 text-muted-foreground">
                      {displayLocation?.image || assignment.delivery || "-"}
                      {pendingDraft && (
                        <span className="ml-2 text-[10px] text-emerald-600 font-medium uppercase tracking-wide">
                          Pending Save
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="py-1.5">
                      <div className="flex justify-center gap-1">
                        <button
                          onClick={() => startEdit(key)}
                          className="rounded p-1 hover:bg-muted text-muted-foreground hover:text-foreground"
                        >
                          <PencilIcon className="size-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(assignment)}
                          className="rounded p-1 hover:bg-red-100 dark:hover:bg-red-900/40 text-muted-foreground hover:text-red-500"
                        >
                          <Trash2Icon className="size-3.5" />
                        </button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
              {selectedRouteId &&
                visibleAssignments.length === 0 &&
                !adding && (
                  <TableRow>
                    <TableCell
                      colSpan={4}
                      className="py-10 text-center text-muted-foreground"
                    >
                      No locations assigned to this route yet.
                    </TableCell>
                  </TableRow>
                )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  )
}
